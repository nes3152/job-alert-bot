# Job Alert Bot 🎯

A multi-platform job scraper that monitors **LinkedIn, Indeed, Glassdoor, and Handshake** for Data Analyst / Data Science roles — and emails you a daily digest ranked by how well each job matches your resume.

Built to solve a real problem: spending hours manually checking job boards every day.

---

## Features

| Feature | Description |
|---|---|
| 🔍 **Multi-platform scraping** | LinkedIn · Indeed · Glassdoor · Handshake |
| 🤖 **AI match scoring** | Scores each job 0–100% based on your resume keywords |
| 📨 **Email digest** | Daily HTML email, sorted by match score |
| 💬 **Slack alerts** | Optional Slack notifications |
| 📁 **Application tracker** | Track status: unseen → saved → applied → interview → offer / rejected |
| 🖥️ **CLI interface** | Custom keywords, locations, tracker commands |
| 🔐 **Secure config** | Credentials in `config.yaml` (gitignored) or env vars |

---

## Quickstart

```bash
# 1. Clone and install
git clone https://github.com/nes3152/job-alert-bot.git
cd job-alert-bot
pip install -r requirements.txt

# 2. Set up config
cp config.example.yaml config.yaml
# Edit config.yaml — add your email, resume text, etc.

# 3. Run
python job_bot.py
```

---

## CLI Usage

```bash
# Normal daily run (uses config.yaml keywords/locations)
python job_bot.py

# Search a specific keyword + location
python job_bot.py --keyword "ML Engineer" --location "New York, NY"
python job_bot.py -k "Analytics Engineer" -l "Seattle, WA"

# View your application tracker
python job_bot.py --tracker

# Update a job's status
python job_bot.py --mark <job_id> applied
python job_bot.py --mark <job_id> interview
```

**Tracker statuses:** `unseen` → `saved` → `applied` → `interview` → `offer` / `rejected`

---

## Match Scoring

Each job gets a **0–100% match score** based on keyword overlap between the job title/description and your resume (configured in `config.yaml`).

| Score | Label |
|---|---|
| 75–100% | 🟢 Strong |
| 45–74% | 🟡 Good |
| 0–44% | ⚪ Low |

Jobs are sorted by score in the email digest so you can prioritize the best fits first.

---

## Config & Credentials

Copy `config.example.yaml` → `config.yaml` and fill in:

```yaml
email:
  sender: "your_gmail@gmail.com"
  password: "your_app_password"   # Gmail App Password
  recipients:
    - "you@gmail.com"
```

> **Gmail App Password:** Go to Google Account → Security → 2-Step Verification → App Passwords. Generate one for "Mail".

Alternatively, use environment variables:

```bash
export EMAIL_SENDER="you@gmail.com"
export EMAIL_PASSWORD="your_app_password"
export EMAIL_RECIPIENTS="you@gmail.com"
export SLACK_WEBHOOK="https://hooks.slack.com/..."
```

---

## Automate with Cron

Run every day at 8am:

```bash
crontab -e
# Add:
0 8 * * * cd /path/to/job-alert-bot && python job_bot.py
```

---

## Tech Stack

- **Python** — scraping, data processing, notifications
- **BeautifulSoup** — HTML parsing
- **Requests** — HTTP
- **PyYAML** — config management
- **smtplib** — email via Gmail SMTP

---

## Project Structure

```
job-alert-bot/
├── job_bot.py           # Main script
├── config.example.yaml  # Config template (safe to commit)
├── config.yaml          # Your real config (gitignored)
├── requirements.txt
├── seen_jobs.json        # Dedup cache (gitignored)
├── tracker.json          # Application tracker (gitignored)
└── .gitignore
```

---

*Built by Jack (Euisuk Nha) · UC Berkeley Data Science '26*
