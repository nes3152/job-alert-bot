"""
Job Alert Bot — Jack (Euisuk Nha)
Scrapes LinkedIn, Handshake, Glassdoor, Indeed for Data Analyst / Data Science roles
Sends daily digest via Email + Slack

Upgrades:
  1. AI Match Scoring  — keyword-based resume fit score (0–100) per job
  2. Application Tracker — track status per job in tracker.json
  3. CLI Interface     — run with custom flags
  4. Match Score in Email — priority column in digest
  5. config.yaml       — all credentials/settings externalized

Usage:
  python job_bot.py                                  # normal daily run
  python job_bot.py --keyword "ML Engineer" --location "NYC"
  python job_bot.py --tracker                        # print tracker summary
  python job_bot.py --mark <job_id> applied          # update tracker status
"""

import os
import json
import time
import hashlib
import smtplib
import logging
import argparse
import re
import yaml
import requests
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from bs4 import BeautifulSoup
from dataclasses import dataclass, field

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# CONFIG LOADER  (Feature 5)
# ─────────────────────────────────────────────

def load_config(path="config.yaml") -> dict:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    cfg["email"]["sender"]   = os.getenv("EMAIL_SENDER",   cfg["email"].get("sender", ""))
    cfg["email"]["password"] = os.getenv("EMAIL_PASSWORD", cfg["email"].get("password", ""))
    recipients_env = os.getenv("EMAIL_RECIPIENTS", "")
    if recipients_env:
        cfg["email"]["recipients"] = [r.strip() for r in recipients_env.split(",")]
    cfg["slack"]["webhook"] = os.getenv("SLACK_WEBHOOK", cfg["slack"].get("webhook", ""))
    return cfg

CONFIG = load_config()

# ─────────────────────────────────────────────
# AI MATCH SCORING  (Feature 1)
# ─────────────────────────────────────────────

def build_resume_keywords(resume_text: str) -> list:
    skill_patterns = [
        r"python", r"sql", r"pandas", r"numpy", r"pytorch", r"tensorflow",
        r"scikit.?learn", r"spark", r"airflow", r"dbt",
        r"tableau", r"power.?bi", r"looker", r"metabase",
        r"aws", r"gcp", r"azure", r"docker", r"linux", r"bash", r"git",
        r"machine.?learning", r"deep.?learning", r"nlp", r"analytics",
        r"statistics", r"visualization", r"dashboard", r"a.?b.?test",
        r"finance", r"business", r"data.?analyst", r"data.?scientist",
    ]
    text = resume_text.lower()
    return [p for p in skill_patterns if re.search(p, text, re.IGNORECASE)]

RESUME_KEYWORDS = build_resume_keywords(CONFIG.get("resume", ""))

def match_score(job: "Job") -> int:
    if not RESUME_KEYWORDS:
        return 0
    jd = f"{job.title} {job.company} {job.description}".lower()
    hits = sum(1 for kw in RESUME_KEYWORDS if re.search(kw, jd, re.IGNORECASE))
    score = min(100, int((hits / max(len(RESUME_KEYWORDS), 1)) * 200))
    for kw in ["data analyst", "data scientist", "analytics engineer", "business analyst"]:
        if kw in job.title.lower():
            score = min(100, score + 20)
            break
    return score

def score_label(score: int) -> str:
    if score >= 75: return "🟢 Strong"
    if score >= 45: return "🟡 Good"
    return "⚪ Low"

# ─────────────────────────────────────────────
# Data model
# ─────────────────────────────────────────────

@dataclass
class Job:
    title: str
    company: str
    location: str
    url: str
    source: str
    posted: str = ""
    description: str = ""
    score: int = 0
    id: str = field(default="", init=False)

    def __post_init__(self):
        self.id = hashlib.md5(f"{self.title}{self.company}{self.url}".encode()).hexdigest()
        self.score = match_score(self)

    def is_relevant(self):
        title_lower = self.title.lower()
        exclude = [k.lower() for k in CONFIG["search"]["exclude_keywords"]]
        return not any(ex in title_lower for ex in exclude)

# ─────────────────────────────────────────────
# APPLICATION TRACKER  (Feature 2)
# ─────────────────────────────────────────────

TRACKER_STATUSES = ["unseen", "saved", "applied", "interview", "offer", "rejected"]

def load_tracker() -> dict:
    path = CONFIG.get("tracker_file", "tracker.json")
    try:
        with open(path) as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_tracker(tracker: dict):
    path = CONFIG.get("tracker_file", "tracker.json")
    with open(path, "w") as f:
        json.dump(tracker, f, indent=2)

def track_jobs(jobs: list) -> dict:
    tracker = load_tracker()
    added = 0
    for job in jobs:
        if job.id not in tracker:
            tracker[job.id] = {
                "title": job.title,
                "company": job.company,
                "location": job.location,
                "url": job.url,
                "source": job.source,
                "score": job.score,
                "status": "unseen",
                "added": datetime.now().isoformat(),
                "updated": datetime.now().isoformat(),
                "notes": ""
            }
            added += 1
    save_tracker(tracker)
    log.info(f"📁 Tracker: {added} new jobs added")
    return tracker

def update_tracker_status(job_id: str, status: str):
    if status not in TRACKER_STATUSES:
        print(f"Invalid status. Choose from: {', '.join(TRACKER_STATUSES)}")
        return
    tracker = load_tracker()
    if job_id not in tracker:
        print(f"Job ID not found: {job_id}")
        return
    tracker[job_id]["status"] = status
    tracker[job_id]["updated"] = datetime.now().isoformat()
    save_tracker(tracker)
    job = tracker[job_id]
    print(f"✅ {job['title']} @ {job['company']} → {status}")

def print_tracker_summary():
    tracker = load_tracker()
    if not tracker:
        print("No jobs tracked yet.")
        return
    by_status = {s: [] for s in TRACKER_STATUSES}
    for jid, job in tracker.items():
        by_status[job["status"]].append((jid, job))
    icons = {"unseen":"👀","saved":"💾","applied":"📨","interview":"🎤","offer":"🎉","rejected":"❌"}
    print(f"\n{'='*70}")
    print(f"  JOB TRACKER  —  {datetime.now().strftime('%Y-%m-%d')}")
    print(f"{'='*70}")
    for status in TRACKER_STATUSES:
        jobs = by_status[status]
        if not jobs:
            continue
        print(f"\n{icons[status]}  {status.upper()}  ({len(jobs)})")
        print(f"  {'TITLE':<35} {'COMPANY':<20} {'SCORE':>5}")
        print(f"  {'-'*62}")
        for jid, job in sorted(jobs, key=lambda x: x[1]["score"], reverse=True):
            title   = (job["title"][:33]   + "..") if len(job["title"])   > 35 else job["title"]
            company = (job["company"][:18] + "..") if len(job["company"]) > 20 else job["company"]
            print(f"  {title:<35} {company:<20} {job['score']:>4}%")
            print(f"  ID: {jid[:16]}  {job['url'][:48]}")
    print(f"\n{'='*70}\n")

# ─────────────────────────────────────────────
# Scrapers
# ─────────────────────────────────────────────

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
}


def scrape_linkedin(keyword: str, location: str) -> list:
    jobs = []
    try:
        url = (
            f"https://www.linkedin.com/jobs/search/"
            f"?keywords={requests.utils.quote(keyword)}"
            f"&location={requests.utils.quote(location)}"
            f"&f_TPR=r86400&f_E=1,2"
        )
        resp = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(resp.text, "html.parser")
        for card in soup.select("div.base-card")[:20]:
            title_el   = card.select_one("h3.base-search-card__title")
            company_el = card.select_one("h4.base-search-card__subtitle")
            location_el = card.select_one("span.job-search-card__location")
            link_el    = card.select_one("a.base-card__full-link")
            time_el    = card.select_one("time")
            if not title_el or not link_el:
                continue
            jobs.append(Job(
                title=title_el.get_text(strip=True),
                company=company_el.get_text(strip=True) if company_el else "Unknown",
                location=location_el.get_text(strip=True) if location_el else location,
                url=link_el.get("href", "").split("?")[0],
                source="LinkedIn",
                posted=time_el.get("datetime", "") if time_el else "",
            ))
        log.info(f"LinkedIn: {len(jobs)} jobs for '{keyword}'")
    except Exception as e:
        log.warning(f"LinkedIn scrape failed: {e}")
    return jobs


def scrape_indeed(keyword: str, location: str) -> list:
    jobs = []
    try:
        url = (
            f"https://www.indeed.com/jobs"
            f"?q={requests.utils.quote(keyword)}"
            f"&l={requests.utils.quote(location)}"
            f"&fromage=1&explvl=entry_level"
        )
        resp = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(resp.text, "html.parser")
        for card in soup.select("div.job_seen_beacon")[:20]:
            title_el   = card.select_one("h2.jobTitle span")
            company_el = card.select_one("span.companyName")
            location_el = card.select_one("div.companyLocation")
            link_el    = card.select_one("h2.jobTitle a")
            if not title_el or not link_el:
                continue
            href = link_el.get("href", "")
            jobs.append(Job(
                title=title_el.get_text(strip=True),
                company=company_el.get_text(strip=True) if company_el else "Unknown",
                location=location_el.get_text(strip=True) if location_el else location,
                url=f"https://www.indeed.com{href}" if href.startswith("/") else href,
                source="Indeed",
            ))
        log.info(f"Indeed: {len(jobs)} jobs for '{keyword}'")
    except Exception as e:
        log.warning(f"Indeed scrape failed: {e}")
    return jobs


def scrape_glassdoor(keyword: str, location: str) -> list:
    jobs = []
    try:
        url = (
            f"https://www.glassdoor.com/Job/jobs.htm"
            f"?sc.keyword={requests.utils.quote(keyword)}"
            f"&locT=C&locId=1147401&fromAge=1"
        )
        resp = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(resp.text, "html.parser")
        for card in soup.select("li.react-job-listing")[:20]:
            title_el   = card.select_one("a.jobLink span")
            company_el = card.select_one("div.jobEmpolyerName")
            location_el = card.select_one("span.loc")
            link_el    = card.select_one("a.jobLink")
            if not title_el or not link_el:
                continue
            href = link_el.get("href", "")
            jobs.append(Job(
                title=title_el.get_text(strip=True),
                company=company_el.get_text(strip=True) if company_el else "Unknown",
                location=location_el.get_text(strip=True) if location_el else location,
                url=f"https://www.glassdoor.com{href}" if href.startswith("/") else href,
                source="Glassdoor",
            ))
        log.info(f"Glassdoor: {len(jobs)} jobs for '{keyword}'")
    except Exception as e:
        log.warning(f"Glassdoor scrape failed: {e}")
    return jobs


def scrape_handshake(keyword: str) -> list:
    jobs = []
    try:
        url = (
            f"https://app.joinhandshake.com/stu/postings"
            f"?query={requests.utils.quote(keyword)}"
            f"&page=1&per_page=20&sort_direction=desc&sort_column=created_at"
            f"&job_type_names[]=Job&job_type_names[]=Internship"
        )
        resp = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(resp.text, "html.parser")
        for card in soup.select("div[data-hook='jobs-card']")[:20]:
            title_el   = card.select_one("a[data-hook='jobs-card-title']")
            company_el = card.select_one("span[data-hook='jobs-card-employer']")
            location_el = card.select_one("span[data-hook='jobs-card-location']")
            if not title_el:
                continue
            href = title_el.get("href", "")
            jobs.append(Job(
                title=title_el.get_text(strip=True),
                company=company_el.get_text(strip=True) if company_el else "Unknown",
                location=location_el.get_text(strip=True) if location_el else "N/A",
                url=f"https://app.joinhandshake.com{href}" if href.startswith("/") else href,
                source="Handshake",
            ))
        log.info(f"Handshake: {len(jobs)} jobs for '{keyword}'")
    except Exception as e:
        log.warning(f"Handshake scrape failed: {e}")
    return jobs

# ─────────────────────────────────────────────
# Cache (dedup)
# ─────────────────────────────────────────────

def load_cache() -> set:
    try:
        with open(CONFIG["cache_file"]) as f:
            return set(json.load(f))
    except FileNotFoundError:
        return set()

def save_cache(seen: set):
    with open(CONFIG["cache_file"], "w") as f:
        json.dump(list(seen), f)

# ─────────────────────────────────────────────
# Notifications  (Feature 4: match score column)
# ─────────────────────────────────────────────

def send_email(jobs: list):
    cfg = CONFIG["email"]
    if not cfg.get("sender") or not cfg.get("password"):
        log.warning("Email not configured — skipping.")
        return

    jobs = sorted(jobs, key=lambda j: j.score, reverse=True)
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"🎯 {len(jobs)} New Data Jobs — {datetime.now().strftime('%b %d')}"
    msg["From"] = cfg["sender"]
    msg["To"]   = ", ".join(cfg["recipients"])

    text_lines = [f"New jobs — {datetime.now().strftime('%Y-%m-%d')}\n"]
    for j in jobs:
        text_lines.append(f"[{j.source}] [{j.score}%] {j.title} @ {j.company} ({j.location})\n{j.url}\n")

    source_colors = {"LinkedIn":"#0A66C2","Indeed":"#003A9B","Glassdoor":"#0CAA41","Handshake":"#E8553E"}

    def sbg(s): return "#d4edda" if s>=75 else "#fff3cd" if s>=45 else "#f8f9fa"
    def sfg(s): return "#155724" if s>=75 else "#856404" if s>=45 else "#6c757d"

    rows = ""
    for j in jobs:
        color = source_colors.get(j.source, "#666")
        rows += f"""
        <tr>
          <td style="padding:12px 8px;border-bottom:1px solid #f0f0f0;">
            <a href="{j.url}" style="font-weight:600;color:#111;text-decoration:none;font-size:14px;">{j.title}</a><br>
            <span style="color:#555;font-size:13px;">{j.company} · {j.location}</span>
          </td>
          <td style="padding:12px 8px;border-bottom:1px solid #f0f0f0;text-align:center;">
            <span style="background:{sbg(j.score)};color:{sfg(j.score)};padding:3px 8px;border-radius:4px;font-size:12px;font-weight:600;">{j.score}%</span>
          </td>
          <td style="padding:12px 8px;border-bottom:1px solid #f0f0f0;white-space:nowrap;">
            <span style="background:{color};color:white;padding:2px 8px;border-radius:4px;font-size:11px;">{j.source}</span>
          </td>
          <td style="padding:12px 8px;border-bottom:1px solid #f0f0f0;">
            <a href="{j.url}" style="color:#0A66C2;font-size:13px;">Apply →</a>
          </td>
        </tr>"""

    html_body = f"""
    <html><body style="font-family:-apple-system,sans-serif;max-width:750px;margin:0 auto;color:#111;">
      <div style="background:#111;color:white;padding:20px 24px;border-radius:8px 8px 0 0;">
        <h2 style="margin:0;font-size:20px;">🎯 {len(jobs)} New Data Jobs</h2>
        <p style="margin:4px 0 0;color:#aaa;font-size:13px;">{datetime.now().strftime('%A, %B %d %Y')} · Sorted by match score</p>
      </div>
      <table width="100%" style="border-collapse:collapse;background:white;border:1px solid #eee;border-top:none;">
        <thead><tr style="background:#f8f8f8;">
          <th style="text-align:left;padding:10px 8px;font-size:12px;color:#888;font-weight:500;">POSITION</th>
          <th style="text-align:center;padding:10px 8px;font-size:12px;color:#888;font-weight:500;">MATCH</th>
          <th style="text-align:left;padding:10px 8px;font-size:12px;color:#888;font-weight:500;">SOURCE</th>
          <th style="text-align:left;padding:10px 8px;font-size:12px;color:#888;font-weight:500;">LINK</th>
        </tr></thead>
        <tbody>{rows}</tbody>
      </table>
      <p style="font-size:12px;color:#aaa;padding:12px 0;">키워드: {', '.join(CONFIG['search']['keywords'])} · 자동 발송됨</p>
    </body></html>"""

    msg.attach(MIMEText("\n".join(text_lines), "plain"))
    msg.attach(MIMEText(html_body, "html"))
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(cfg["sender"], cfg["password"])
            server.sendmail(cfg["sender"], cfg["recipients"], msg.as_string())
        log.info(f"✅ Email sent: {len(jobs)} jobs")
    except Exception as e:
        log.error(f"Email failed: {e}")


def send_slack(jobs: list):
    webhook = CONFIG["slack"].get("webhook", "")
    if not webhook:
        log.info("Slack webhook not configured, skipping.")
        return
    jobs = sorted(jobs, key=lambda j: j.score, reverse=True)
    blocks = [
        {"type": "header", "text": {"type": "plain_text", "text": f"🎯 {len(jobs)} New Data Jobs — {datetime.now().strftime('%b %d')}"}},
        {"type": "divider"},
    ]
    for j in jobs[:10]:
        blocks.append({"type": "section", "text": {"type": "mrkdwn",
            "text": f"*<{j.url}|{j.title}>*  {score_label(j.score)} `{j.score}%`\n{j.company} · {j.location} · `{j.source}`"}})
    if len(jobs) > 10:
        blocks.append({"type": "section", "text": {"type": "mrkdwn",
            "text": f"_...and {len(jobs)-10} more. Check your email._"}})
    try:
        resp = requests.post(webhook, json={"blocks": blocks}, timeout=10)
        log.info(f"✅ Slack sent: {resp.status_code}")
    except Exception as e:
        log.error(f"Slack failed: {e}")

# ─────────────────────────────────────────────
# Main runner
# ─────────────────────────────────────────────

def run(extra_keyword=None, extra_location=None):
    log.info("🔍 Starting job scrape...")
    seen = load_cache()
    all_jobs = []

    keywords  = [extra_keyword]  if extra_keyword  else CONFIG["search"]["keywords"]
    locations = [extra_location] if extra_location else CONFIG["search"]["locations"]

    for keyword in keywords:
        for loc in locations:
            all_jobs += scrape_linkedin(keyword, loc)
            all_jobs += scrape_indeed(keyword, loc)
            all_jobs += scrape_glassdoor(keyword, loc)
            time.sleep(2)
        all_jobs += scrape_handshake(keyword)
        time.sleep(1)

    new_jobs = []
    seen_ids = set()
    for job in all_jobs:
        if job.id not in seen and job.id not in seen_ids and job.is_relevant():
            new_jobs.append(job)
            seen.add(job.id)
            seen_ids.add(job.id)

    log.info(f"📋 Found {len(new_jobs)} new unique jobs")

    if new_jobs:
        track_jobs(new_jobs)
        send_email(new_jobs)
        send_slack(new_jobs)
        save_cache(seen)
        top = sorted(new_jobs, key=lambda j: j.score, reverse=True)[:5]
        print(f"\n🏆 Top {len(top)} matches today:")
        for j in top:
            print(f"  {score_label(j.score)} {j.score}%  {j.title} @ {j.company}  [{j.source}]")
    else:
        log.info("No new jobs found today.")

    return new_jobs

# ─────────────────────────────────────────────
# CLI  (Feature 3)
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Job Alert Bot — Data Analyst / DS roles")
    parser.add_argument("--keyword",  "-k", type=str, help="Override search keyword")
    parser.add_argument("--location", "-l", type=str, help="Override search location")
    parser.add_argument("--tracker",  "-t", action="store_true", help="Print tracker summary")
    parser.add_argument("--mark", "-m", nargs=2, metavar=("JOB_ID", "STATUS"),
                        help=f"Update job status: {', '.join(TRACKER_STATUSES)}")
    args = parser.parse_args()

    if args.tracker:
        print_tracker_summary()
    elif args.mark:
        update_tracker_status(args.mark[0], args.mark[1])
    else:
        run(extra_keyword=args.keyword, extra_location=args.location)

if __name__ == "__main__":
    main()
